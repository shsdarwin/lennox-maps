<html>
<head></head>
<body style="margin: 0 auto">
	<div style="background: #337ab7; color: #fff; padding: 20px">
		<h3>{{$subject}}</h3>
	</div>
	<div style="color: #333; padding: 20px">
		<p>{{$content}}</p>
	</div>
</body>
</html>